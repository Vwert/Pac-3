player_manager.AddValidModel( "Sigma T2-A2",		"models/helios/sigmat2a2.mdl" );
list.Set( "PlayerOptionsModel", "Sigma T2-A2",		"models/helios/sigmat2a2.mdl" );